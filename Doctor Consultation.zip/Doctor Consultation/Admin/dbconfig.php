				<?php

				$conn = new mysqli('localhost', 'root', '', 'wt_database') 
					or die ('Cannot connect to db');
				?>