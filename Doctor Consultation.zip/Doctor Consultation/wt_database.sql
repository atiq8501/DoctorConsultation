-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 18, 2019 at 10:44 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wt_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `Username` varchar(30) NOT NULL,
  `Fname` varchar(30) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `CID` int(5) NOT NULL,
  `DID` int(5) NOT NULL,
  `DOV` date NOT NULL,
  `Timestamp` datetime NOT NULL,
  `Status` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`Username`, `Fname`, `Gender`, `CID`, `DID`, `DOV`, `Timestamp`, `Status`) VALUES
('user', 'patient', 'male', 1, 1, '2017-11-08', '2017-11-05 16:43:48', 'Booking Registered.Wait for the update'),
('user', 'Atiqur Rahman', 'male', 3, 2, '2019-08-12', '2019-08-09 18:37:38', 'Booking Registered.Wait for the update'),
('atiqur.foyshal', 'Atiqur Rahman', 'male', 3, 2, '2019-08-19', '2019-08-17 12:03:25', 'Cancelled by Patient'),
('user', 'Atiqur Rahman', 'other', 3, 2, '2019-08-22', '2019-08-18 06:14:47', 'Cancelled by Patient'),
('user', 'Atiqur Rahman', 'male', 7, 8, '2019-08-20', '2019-08-18 09:58:29', 'Booking Registered.Wait for the update'),
('user', 'Atiqur Rahman', 'male', 3, 2, '2019-08-23', '2019-08-18 10:15:10', 'Booking Registered.Wait for the update'),
('atiqur.foyshal', 'Atiqur Rahman', 'male', 25, 99, '2019-08-20', '2019-08-18 10:30:38', 'Booking Registered.Wait for the update');

-- --------------------------------------------------------

--
-- Table structure for table `clinic`
--

CREATE TABLE `clinic` (
  `cid` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `address` varchar(100) NOT NULL,
  `town` varchar(30) NOT NULL,
  `city` varchar(30) NOT NULL,
  `contact` bigint(20) NOT NULL,
  `mid` varchar(5) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clinic`
--

INSERT INTO `clinic` (`cid`, `name`, `address`, `town`, `city`, `contact`, `mid`) VALUES
(7, 'Faridpur Medical', 'Faridpur Main Road', 'Main Road', 'Faridpur', 896547, ''),
(5, 'Popular Medical', 'road 1', 'Dhanmandi', 'Dhaka', 88000000000000000, ''),
(3, 'Barishal Clinic', 'Barishal', 'Barishal', 'Barishal', 886656955, '3'),
(6, 'Dinajpur Hospital', 'Dinajpur', 'Dinajpur', 'Dinajpur', 5525522225, ''),
(8, 'Rajbari Government Medical Hos', 'Rajbari Sadar Road', 'Sadar', 'Rajbari', 6579464, ''),
(25, 'Bogra Clinic', 'Bogra', 'Bogra', 'Bogra', 66665255, '2');

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `did` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `dob` date NOT NULL,
  `experience` int(11) NOT NULL,
  `specialization` varchar(30) NOT NULL,
  `contact` bigint(20) NOT NULL,
  `address` varchar(100) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `region` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`did`, `name`, `gender`, `dob`, `experience`, `specialization`, `contact`, `address`, `username`, `password`, `region`) VALUES
(3, 'atiqur faisal', 'male', '1998-08-15', 3, 'dentist', 12563937, 'sirajgong', 'atiq', '1234', 'Sirajgonj'),
(10, 'orid', 'male', '1998-10-09', 2, 'Dentist', 1793903424, 'Rajshahi', 'orid', 'orid', 'Rajshahi'),
(2, 'abcd', 'male', '2019-10-06', 5, 'ent', 4444444, 'Barishal', 'userdoctor', '1234', 'Barishal'),
(4, 'Shahrina', 'female', '1999-10-13', 4, 'Surgery', 343262, 'dinajpur', 'shahrina', 'shahrina', 'dinajpur'),
(5, 'Likhon Sarker', 'male', '1998-08-02', 2, 'ent', 627920, 'Siarajganj', 'likhon', '1234', 'Sirajganj'),
(7, 'Sumya Meem', 'female', '1999-08-08', 2, 'Cardiologist', 6579303, 'Goalanda, Rajbari', 'meem', '890', 'Rajbari'),
(8, 'Shimu Islam', 'female', '1998-08-17', 5, 'Gynochologist', 654793, 'Faridpur TakerHat', 'Shimu', '567', 'Faridpur'),
(99, 'Sabbir', 'male', '1990-10-20', 5, 'Cardiologist', 88017777777777, 'Bogra', 'sabbir', 'sabbir', 'Bogra');

-- --------------------------------------------------------

--
-- Table structure for table `doctor_availability`
--

CREATE TABLE `doctor_availability` (
  `cid` int(11) NOT NULL,
  `did` int(11) NOT NULL,
  `day` varchar(50) NOT NULL,
  `starttime` time NOT NULL,
  `endtime` time NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor_availability`
--

INSERT INTO `doctor_availability` (`cid`, `did`, `day`, `starttime`, `endtime`) VALUES
(1, 1, 'Friday', '14:00:00', '18:00:00'),
(1, 1, 'Monday', '14:00:00', '18:00:00'),
(1, 1, 'Thursday', '14:00:00', '18:00:00'),
(1, 1, 'Tuesday', '14:00:00', '18:00:00'),
(1, 1, 'Wednesday', '14:00:00', '18:00:00'),
(3, 2, 'Friday', '08:11:00', '12:45:00'),
(3, 2, 'Monday', '00:00:00', '23:00:00'),
(3, 2, 'Monday', '01:31:00', '16:30:00'),
(3, 2, 'Monday', '08:11:00', '12:45:00'),
(3, 2, 'Thursday', '01:31:00', '16:30:00'),
(3, 2, 'Tuesday', '01:31:00', '16:30:00'),
(3, 2, 'Tuesday', '08:11:00', '12:45:00'),
(3, 2, 'Wednesday', '01:31:00', '16:30:00'),
(5, 0, 'Monday', '12:10:00', '15:20:00'),
(5, 0, 'Monday', '13:54:00', '15:00:00'),
(6, 4, 'Monday', '12:00:00', '14:00:00'),
(6, 4, 'Tuesday', '12:00:00', '14:00:00'),
(6, 4, 'Wednesday', '12:00:00', '14:00:00'),
(7, 8, 'Monday', '12:56:00', '17:34:00'),
(7, 8, 'Tuesday', '12:56:00', '17:34:00'),
(7, 8, 'Wednesday', '12:56:00', '17:34:00'),
(8, 7, 'Monday', '11:06:00', '18:05:00'),
(8, 7, 'Thursday', '11:06:00', '18:05:00'),
(8, 7, 'Wednesday', '11:06:00', '18:05:00'),
(25, 99, 'Friday', '09:00:00', '16:00:00'),
(25, 99, 'Thursday', '09:00:00', '16:00:00'),
(25, 99, 'Tuesday', '09:00:00', '16:00:00'),
(25, 99, 'Wednesday', '09:00:00', '16:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `manager`
--

CREATE TABLE `manager` (
  `mid` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `dob` date NOT NULL,
  `contact` bigint(20) NOT NULL,
  `address` varchar(100) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `region` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `manager`
--

INSERT INTO `manager` (`mid`, `name`, `gender`, `dob`, `contact`, `address`, `username`, `password`, `region`) VALUES
(1, 'Manager', 'male', '1995-10-09', 88078888888888, 'Dhaka', 'manager', 'manager', 'Dhaka'),
(3, 'Mr Manager 2', 'male', '1998-02-01', 889996555556, 'Barishal', 'usermanager', '1234', 'Barishal'),
(5, 'Sabbir', 'male', '1997-08-21', 12357, 'Faridpur TakerHat', 'Sabbir', 'sabbir', 'Faridpur'),
(2, 'Likhon', 'male', '1999-10-20', 5555568225, 'Bogra', 'likhon', 'likhon', 'Bogra');

-- --------------------------------------------------------

--
-- Table structure for table `manager_clinic`
--

CREATE TABLE `manager_clinic` (
  `cid` int(11) NOT NULL,
  `mid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `manager_clinic`
--

INSERT INTO `manager_clinic` (`cid`, `mid`) VALUES
(1, 1),
(3, 3),
(25, 2);

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `name` varchar(30) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `dob` date NOT NULL,
  `contact` bigint(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`name`, `gender`, `dob`, `contact`, `email`, `username`, `password`) VALUES
('user', 'male', '1985-01-01', 7897897897, 'user@test.com', 'user', 'user'),
('Atiqur Rahman', 'male', '1997-11-12', 1750492858, 'atiqur.foyshal@gmail.com', 'atiqur.foyshal', 'atiq1234');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`Username`,`Fname`,`DOV`,`Timestamp`);

--
-- Indexes for table `clinic`
--
ALTER TABLE `clinic`
  ADD PRIMARY KEY (`cid`,`name`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`did`);

--
-- Indexes for table `doctor_availability`
--
ALTER TABLE `doctor_availability`
  ADD PRIMARY KEY (`cid`,`did`,`day`,`starttime`,`endtime`);

--
-- Indexes for table `manager`
--
ALTER TABLE `manager`
  ADD PRIMARY KEY (`mid`);

--
-- Indexes for table `manager_clinic`
--
ALTER TABLE `manager_clinic`
  ADD PRIMARY KEY (`cid`,`mid`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`email`,`username`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
